export class UserModel {
    constructor(
        public NameIdentifier: string,
        public Name: string,
        public Email: string,
        public Gender: string,
        public DateOfBirth: string,
        public Role: string
    ) { }
}
