import { PassengerDto } from './passenger-dto';

describe('PassengerDto', () => {
  it('should create an instance', () => {
    expect(new PassengerDto()).toBeTruthy();
  });
});
