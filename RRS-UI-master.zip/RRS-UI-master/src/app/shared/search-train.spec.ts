import { SearchTrain } from './search-train';

describe('SearchTrain', () => {
  it('should create an instance', () => {
    expect(new SearchTrain()).toBeTruthy();
  });
});
