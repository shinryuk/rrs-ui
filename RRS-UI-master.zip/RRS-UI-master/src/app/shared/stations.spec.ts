import { Stations } from './stations';

describe('Stations', () => {
  it('should create an instance', () => {
    expect(new Stations()).toBeTruthy();
  });
});
