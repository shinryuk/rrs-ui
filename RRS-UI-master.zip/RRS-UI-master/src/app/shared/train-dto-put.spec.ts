import { TrainDtoPut } from './train-dto-put';

describe('TrainDtoPut', () => {
  it('should create an instance', () => {
    expect(new TrainDtoPut()).toBeTruthy();
  });
});
