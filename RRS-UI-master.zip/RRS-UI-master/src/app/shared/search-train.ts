export class SearchTrain {
    constructor(
        public From:string,
        public To:string,
        public TrainDate:string
        
    ){}
}
