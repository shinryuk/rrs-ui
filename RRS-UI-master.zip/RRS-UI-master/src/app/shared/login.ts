export class Login {
    constructor(
        public UserId: number,
        public Password:string
    ){}
}
