import { ReservationDto } from './reservation-dto';

describe('ReservationDto', () => {
  it('should create an instance', () => {
    expect(new ReservationDto()).toBeTruthy();
  });
});
