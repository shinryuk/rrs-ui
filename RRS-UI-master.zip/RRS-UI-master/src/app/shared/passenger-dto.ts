export class PassengerDto {
    constructor(
        public  Gender: string,
        public  Name: string,
        public  Age: number,
        public  Phone: string
    ){}
}
