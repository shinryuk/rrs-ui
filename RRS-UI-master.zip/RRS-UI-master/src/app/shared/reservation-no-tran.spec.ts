import { ReservationNoTran } from './reservation-no-tran';

describe('ReservationNoTran', () => {
  it('should create an instance', () => {
    expect(new ReservationNoTran()).toBeTruthy();
  });
});
