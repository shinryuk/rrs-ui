import { SearchResult } from './search-result';

describe('SearchResult', () => {
  it('should create an instance', () => {
    expect(new SearchResult()).toBeTruthy();
  });
});
