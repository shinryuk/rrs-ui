export class PassengerTicket {
    constructor(
        public name:string,
        public age:number,
        public gender:string,
        public phone:string,
        public seat:number
    ){}
}
