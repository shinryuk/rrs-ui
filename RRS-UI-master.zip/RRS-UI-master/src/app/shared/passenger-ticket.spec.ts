import { PassengerTicket } from './passenger-ticket';

describe('PassengerTicket', () => {
  it('should create an instance', () => {
    expect(new PassengerTicket()).toBeTruthy();
  });
});
