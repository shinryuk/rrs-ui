export class Stations {
    public readonly station = [
        'Karachi Cantonment',
        'Landhi Junction',
        'Hyderabad Junction',
        'Tando Adam Junction',
        'Rohri Junction',
        'Rahim Yar Khan',
        'Khanpur Junction',
        'Bahawalpur',
        'Multan Cantonment',
        'Khanewal Junction',
        'Abdul Hakim',
        'Shorkot Cantonment Junction',
        'Toba Tek Singh',
        'Gojra',
        'Faisalabad',
        'Wazirabad Junction',
        'Gujrat',
        'Lala Musa Junction',
        'Jhelum',
        'Rawalpindi'
    ];
}
